export class Admin {
  adminId: number;
  adminName: string;
  contactNumber: string;
  email: string;
  type: String;
  bname:String;
  password: string;

}
